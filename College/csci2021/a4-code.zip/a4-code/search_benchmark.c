#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "search.h"


int main(int argc, char *argv[]){

  if (argc > 5 || argc < 4){
    printf("./usage: ./search_benchmark <minpow> <maxpow> <repeats> [which]\n");
    printf("which is a combination of: \n");
    printf("a : Linear Array Search\n");
    printf("l : Linked List Search\n");
    printf("b : Binary Array Search\n");
    printf("t : Binary Tree Search\n");
    printf("(default all)\n");
    return 1;
  }


  //Initialization of main variables
  int mindata = atoi(argv[1]);
  int maxdata = atoi(argv[2]);
  int repeats = atoi(argv[3]);

    //Initialization of default boolean flags for each graph
  int execute[] = {1,1,1,1};

  //if there is a specific input for the fifth argument
  if (argc == 5){
    char *algchars = argv[4];

    //initialize the flags to 0
    execute[0] = 0;
    execute[1] = 0;
    execute[2] = 0;
    execute[3] = 0;

    //code to switch on and off the flag for the different inputs
    for (int i = 0; i < sizeof(algchars) ; i++){
      if ('a' == algchars[i]){
        execute[0] = 1;
      }
      if ('l' == algchars[i]){
        execute[1] = 1;
      }
      if ('b' == algchars[i]){
        execute[2] = 1;
      }
      if ('t' == algchars[i]){
        execute[3] = 1;
      }
    }
  }

  //print functions for the headers
  printf("%s", "  LENGTH SEARCHES");

  if (execute[0] == 1){
    printf("%11s", "array");
  }
  if (execute[1] == 1){
    printf("%11s", "list");
  }
  if (execute[2] == 1){
    printf("%11s", "binary");
  }
  if (execute[3] == 1){
    printf("%11s", "tree");
  }

  printf("%s\n", "");

  //takes 2 to the power of the min and the max and shows the intevals in between
  for (int i = 0; i <= (maxdata-mindata); i++){
    int length = 1;
    for (int j = 0; j < (mindata + i); j++){
      length = length * 2;
    }
    printf("%8d", length);
    int searches = repeats * length *2;
    printf("%9d", searches);

    //linear array search
    if (execute[0] == 1){
      int *arr = make_evens_array(length);
      clock_t time;
      time = clock();
      for (int r = 0; r < repeats ; r++){
      	for (int x = 0; x < (length*2); x++){
        	linear_array_search(arr, length, x);
      	}	
      }
      time = clock() - time;
      double totaltime = ((double) time)/ CLOCKS_PER_SEC;
      printf("%11.4e", totaltime);
      free(arr);
    }

    //linked list search
    if (execute[1] == 1){
      list_t *lst = make_evens_list(length);
      clock_t time;
      time = clock();
      for (int r = 0 ; r < repeats ; r++){
      	for (int x = 0; x < (length*2); x++){
        	linkedlist_search(lst, length, x);
      	}
      }
      time = clock() - time;
      double totaltime = ((double) time)/ CLOCKS_PER_SEC;
      printf("%11.4e", totaltime);
      list_free(lst);
    }

    //binary array search
    if (execute[2] == 1){
      int *arr = make_evens_array(length);
      clock_t time;
      time = clock();
      for (int r = 0 ; r < repeats ; r++){
      	for (int x = 0; x < (length*2); x++){
        	binary_array_search(arr, length, x);
     	}
      }
      time = clock() - time;
      double totaltime = ((double) time)/ CLOCKS_PER_SEC;
      printf("%11.4e", totaltime);
      free(arr);
    }

    //binary tree search
    if (execute[3] == 1){
      bst_t *bst = make_evens_tree(length);
      clock_t time;
      time = clock();
      for (int r = 0 ; r < repeats ; r++){
      	for (int x = 0; x < (length*2); x++){
        	binary_tree_search(bst, length, x);
      	}
      }
      time = clock() - time;
      double totaltime = ((double) time)/ CLOCKS_PER_SEC;
      printf("%11.4e", totaltime);
      bst_free(bst);
    }
  printf("\n");
  }
  return 0;
}
