#!/bin/bash

chmod 640 private.html
chmod 644 403.html
chmod 644 404.html
chmod 644 MyContacts.html
chmod 644 MyWidgets.html
chmod 644 displayPix.html
chmod 644 bellToll.html
chmod 644 Goldy_N_Bell.html
chmod 644 gophers-mascot.png
chmod 644 tolling-bell_daniel-simion.mp3
chmod 644 MyForm.html
