#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "deltas.h"
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>

void print_graph(int *data, int len, int max_height){

  int main(int argc, char *argv[]){
    if(argc < 3){
      printf("usage: %s <format> <filename>\n",argv[0]);
      printf(" <format> is one of\n");
      printf(" text : text ints are in the given filename\n");
      printf(" int  : binary ints are in the given filename\n");
      printf(" 4bit : 4bit binary ints are in the given filename\n");
      return 1;
    }
    char *format = argv[1];
    char *fname = argv[2];

    int data_len = -1;
    int *data_vals = NULL;
    if( strcmp("text", format)==0 ){
      printf("Reading text format\n");
      data_vals = read_text_deltas(fname, &data_len);
    }
    else if( strcmp("int", format)==0 ){
      printf("Reading binary int format\n");
      data_vals = read_int_deltas(fname, &data_len);
    }
    else if( strcmp("4bit", format)==0 ){
      printf("Reading 4bit binary int format\n");
      //data_vals = read_4bit_deltas(fname, &data_len);
    }
    else{
      printf("Unknown format '%s'\n",format);
      return 1;
    }

    printf("Length : %d\n",data_len);
    printf("min: %d\n", )
    printf("%4s %4s\n","#","read");
    for(int i=0; i<data_len; i++){
      printf("%4d %4d\n",i,data_vals[i]);
    }

    free(data_vals);

    return 0;
  }
}
// Prints a graph of the values in data which is an array of integers
// that has len elements. The max_height argument is the height in
// character rows that the maximum number data[] should be.  A sample
// graph is as follows:
//
// length: 50
// min: 13
// max: 996
// range: 983
// max_height: 10
// units_per_height: 98.30
//      +----+----+----+----+----+----+----+----+----+----
// 996 |                X
// 897 |       X        X X            X
// 799 |  X    X X   X  X X    X       X                X
// 701 |  XX   X X   X  XXX    X      XX   XXX    X   X XX
// 602 |  XX   X X  XX  XXX X  X      XX  XXXX    XX  X XX
// 504 |  XX   XXX  XX  XXX XX X      XXX XXXX XX XX  X XX
// 406 |  XX X XXX XXXX XXX XX X  XXX XXX XXXXXXXXXX  X XX
// 307 | XXX X XXX XXXXXXXXXXX X XXXX XXXXXXXXXXXXXXX X XX
// 209 | XXX XXXXXXXXXXXXXXXXX XXXXXX XXXXXXXXXXXXXXXXX XX
// 111 | XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
//  13 |XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
//      +----+----+----+----+----+----+----+----+----+----
//      0    5    10   15   20   25   30   35   40   45
