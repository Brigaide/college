#include "matvec.h"
#include <stdlib.h>

int optimized_matrix_trans_mult_vec(matrix_t mat, vector_t vec, vector_t res){
  if(mat.rows != vec.len){
    printf("mat.rows (%ld) != vec.len (%ld)\n",mat.rows,vec.len);
    return 1;
  }
  if(mat.cols != res.len){
    printf("mat.cols (%ld) != res.len (%ld)\n",mat.cols,res.len);
    return 2;
  }
  for(int j=0; j<mat.rows; j++){   //
    VSET(res,j,0);
  }
  int remaining = mat.cols - (mat.cols%2);
  for(int j=0; j<mat.rows; j++){
    int veci = VGET(vec,j);           // initialize res[j] to zero
    for(int i=0; i<mat.cols; i+=2){
      int elij1 = MGET(mat,j,i);
      int elij2 = MGET(mat,j,i+1);
      int prod1 = elij1 * veci;
      int prod2 = elij2 * veci;
      int curr1 = VGET(res,i);
      int curr2 = VGET(res,i+1);
      int next1 = curr1 + prod1;
      int next2 = curr2 + prod2;
      VSET(res,i, next1);
      VSET(res,i+1, next2);     // add on the newest product
    }
    for(int i = remaining; i<mat.cols; i++){     // cleanup loop
      int elij1 = MGET(mat,j,i);
      int prod1 = elij1 * veci;
      int curr1 = VGET(res,i);
      int next1 = curr1 + prod1;
      VSET(res,i, next1);
    }
  }
  return 0;
}
