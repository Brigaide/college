#!/usr/bin/env python3
# See https://docs.python.org/3.x/library/socket.html
# for a description of python socket and its parameters
#
# Copyright 2019, Shaden Smith, Koorosh Vaziri,
# Niranjan Tulajapure, Ambuj Nayab,
# Akash Kulkarni, Ruofeng Liu and Daniel J. Challou
# for use by students enrolled in Csci 4131 at the University of
# Minnesota-Twin Cities only. Do not reuse or redistribute further
# without the express written consent of the authors.
#
# This is a reworked version of EchoServer to get you started.
# It responds correctly to a HEAD command.
#add the following
import socket
import os
import stat
import sys
import urllib.parse
import datetime
from threading import Thread
from argparse import ArgumentParser
BUFSIZE = 4096
#add the following
CRLF = '\r\n'
METHOD_NOT_ALLOWED = 'HTTP/1.1 405 METHOD NOT ALLOWED{}Allow: GET,HEAD, POST {}Connection: close{}{}'.format(CRLF, CRLF, CRLF, CRLF)
OK = 'HTTP/1.1 200 OK{}{}'.format(CRLF, CRLF)
NOT_FOUND = 'HTTP/1.1 404 NOT FOUND{}Connection:close{}{}'.format(CRLF, CRLF, CRLF)
FORBIDDEN = 'HTTP/1.1 403 FORBIDDEN{}Connection:close{}{}'.format(CRLF, CRLF, CRLF)
MOVED_PERMANENTLY = 'HTTP/1.1 301 MOVED PERMANENTLY{}Location:https://www.youtube.com/{}Connection: close{}{}'.format(CRLF, CRLF,CRLF, CRLF)
NOT_ACCEPTABLE = 'HTTP/1.1 406 NOT ACCEPTABLE{}Allow: GET,HEAD, POST {}Connection: close{}{}'.format(CRLF, CRLF, CRLF, CRLF)
def get_contents(fname):
    with open(fname, 'r') as f:
        return f.read()

def media_contents(fname):
    with open(fname, 'rb') as f:
        return f.read()

def check_perms(resource):
    """Returns True if resource has read permissions set on
    'others'"""
    stmode = os.stat(resource).st_mode
    return (getattr(stat, 'S_IROTH') & stmode) > 0

def client_talk(client_sock, client_addr): # Not used anymore!!!!
    print('talking to {}'.format(client_addr))
    data = client_sock.recv(BUFSIZE)
    while data:
        print(data.decode('utf-8'))
        data = client_sock.recv(BUFSIZE)
        # clean up
        client_sock.shutdown(1)
        client_sock.close()
    print('connection closed.')

class HTTP_HeadServer: #A re-worked version of EchoServer
    def __init__(self, host, port):
        print('listening on port {}'.format(port))
        self.host = host
        self.port = port
        self.setup_socket()
        self.accept()
        self.sock.shutdown()
        self.sock.close()

    def setup_socket(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.bind((self.host, self.port))
        self.sock.listen(128)

    def accept(self):
        while True:
            (client, address) = self.sock.accept()
            #th = Thread(target=client_talk, args=(client, address))
            th = Thread(target=self.accept_request, args=(client, address))
            th.start()
            # here, we add a function belonging to the class to accept
            # and process a request

    def accept_request(self, client_sock, client_addr):
        print("accept request")
        data = client_sock.recv(BUFSIZE)

        req = data.decode('utf-8') 
        #returns a string with http request

        response=self.process_request(req) 
        #ret string with http response
        #once we get a response, we chop it into utf encoded bytes
        #and send it (like EchoClient)

        if isinstance(response,bytes):
            client_sock.send(response)
        else:
            client_sock.send(bytes(response,'utf-8'))
        #clean up the connection to the client
        #but leave the server socket for recieving requests open
        client_sock.shutdown(1)
        client_sock.close()
        #added method to process requests, only head is handled in this code

    def process_request(self, request):
        print('######\nREQUEST:\n{}######'.format(request))
        linelist = request.strip().split(CRLF)
        reqline = linelist[0] 
        #get the request line

        i = 0
        for line in linelist:
            if line.find('Accept: '):
                compareline = linelist[i]
            else:
                i += 1
        # Iterate through the lines in the request and
        # find the Accept line, then use that line to 
        # compare against the Request line

        rlwords = reqline.split() 
        # get list of strings on request line

        if len(rlwords) == 0:
            return ''
        #if there is no request

        if rlwords[0] == 'HEAD':
            resource = rlwords[1][1:] 
            # skip beginning /
            return self.head_request(resource)
        #Handles Head Request

        elif rlwords[0] == 'GET':
            resource = rlwords[1][1:] 
        # skip beginning /

#--------------------------------- PARSING FOR 406 --------------------------------#

            if (reqline.find('.html')):
                if ((compareline.find("*/*")) or (compareline.find("text/html"))):
                    return self.get_request(resource)
                else:
                    return NOT_ACCEPTABLE + get_contents('406.html')
            elif (reqline.find('.png')):
                if ((compareline.find("*/*")) or (compareline.find("image/*"))):  
                    return self.get_request(resource)
                else:
                    return NOT_ACCEPTABLE + get_contents('406.html')
            elif (reqline.find('.mp3')):
                if ((compareline.find("*/*")) or (compareline.find("audio/*"))):
                    return self.get_request(resource)
                else:
                        return NOT_ACCEPTABLE + get_contents('406.html')

#--------------------------------- PARSING FOR 406 --------------------------------#
        #handles Get Request

        elif rlwords[0] == 'POST':
            resource = linelist[-1]
            return self.post_request(resource)
        else: 
            return METHOD_NOT_ALLOWED + get_contents('405.html')
        #Handles Post Request

    def head_request(self, resource):
        """Handles HEAD requests."""
        path = os.path.join('.', resource) #look in directory where server is running
        if not os.path.exists(resource):
            ret = NOT_FOUND + get_contents('404.html')
        elif not check_perms(resource):
            ret = FORBIDDEN + get_contents('403.html')
        #error checking

        else:
            ret = OK
        return ret
    

    def get_request(self, resource):
        """Handles GET requests."""
        path = os.path.join('.', resource) #look in directory where server is running
        header2 = path.split('/')
        if (header2[1] == 'myTube'):
            return MOVED_PERMANENTLY 
        else:
            header = path.split('.')
            if not os.path.exists(resource):
                ret = NOT_FOUND + get_contents('404.html')
            elif not check_perms(resource):
                ret = FORBIDDEN + get_contents('403.html')
            #check for errors

            else:
                if (header[2] == 'png'):
                    stuff = media_contents(path)
                    ret = bytes(OK, 'utf-8') + stuff
                #if the header requests a png file

                elif (header[2] == 'mp3'):
                    stuff = media_contents(path)
                    ret = bytes(OK, 'utf-8') + stuff
                #if the header requests an mp3 file

                else:
                    stuff = get_contents(path)
                    ret = OK + stuff
                #anything else (html), returna as normal

            return ret


    def post_request(self, resource):
        """Handles POST requests."""
        data = resource.split("&")
        name    = data[0]
        name = name.replace('name=', '')
        name = name.replace('+', ' ')
        #parses through the name and removes/replaces unwanted characters

        email   = data[1]
        email = email.replace('email=', '')
        email = email.replace('%40', '@')
        #parses through the email and removes/replaces unwanted characters

        address = data[2]
        address = address.replace('address=', '')
        address = address.replace('+', ' ')
        address = address.replace('%2C', ',')
        #parses through the address and removes/replaces unwanted characters

        place   = data[3]
        place = place.replace('place=', '')
        place = place.replace('+', ' ')
        #parses through the place and removes/replaces unwanted characters

        url     = data[4]
        url = url.replace('url=', '')
        url = url.replace('%3A', ':')
        url = url.replace('%2F', '/')
        #parses through the url and removes/replaces unwanted characters


        retstr = "<!doctype html><html lang='en'><head><meta charset='utf-8'> \
                </head> \
                <title>Form Input</title> \
                <link rel='stylesheet' type='text/css' href='style.css'> \
                <body> \
                <h1>Form Input</h1> \
                <table> \
                <tr> \
                <td>"  + "Name: " + \
                "<td>" + name + \
                "</tr> \
                <tr> \
                <td>"  + "Email: " + \
                "<td>" + email + \
                "</tr> \
                <tr> \
                <td>"  + "Address: " + \
                "<td>" + address + \
                "</tr> \
                <tr> \
                <td>"  + "Place: " + \
                "<td>" + place + \
                "</tr> \
                <tr> \
                <td>"  + "Url: " + \
                "<td>" + url + \
                "</tr> \
                </body> \
                </html>"
        #string that basically sends an html file that creates a table
        #this table is the form input table that the request writes to

        ret = OK + retstr
        return ret

def parse_args():
    parser = ArgumentParser()
    parser.add_argument('--host', type=str, default='localhost',
    help='specify a host to operate on (default:localhost)')
    parser.add_argument('-p', '--port', type=int, default=9001, help='specify a port to operate on (default:9001)')
    args = parser.parse_args()
    return (args.host, args.port)

if __name__ == '__main__':
    (host, port) = parse_args()
    HTTP_HeadServer(host, port) #Formerly EchoServer
