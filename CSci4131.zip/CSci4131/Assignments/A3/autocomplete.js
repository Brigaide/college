var map;
var geocoder;
function initMap(){
  geocoder = new google.maps.Geocoder();
  map = new google.maps.Map(document.getElementById('map'), {
    center: mpls,
    zoom: 14
  });
  var option = document.getElementById("locationAddr").value;
  alert(option);
  autocomplete = new google.maps.places.Autocomplete(option, {});
  map.addListener("click", function(event){
    geocoder.geocode({
      "latlong": new google.maps.LatLng(event.latLng.lat(), event.latLng.lng()),
      function(results, status){
        document.getElementById("locationAddr".value = results[0].formatted_address)
      }
    });
  })
}
