// include the express module which is a Node.js web application framework
var express = require("express");

// create an express application
var app = express();

// helps in extracting the body portion of an incoming request stream
var bodyparser = require('body-parser');

// fs module - provides an API for interacting with the file system
var fs = require("fs");

// required for reading XML files
var xml2js = require('xml2js');


var parser = new xml2js.Parser();
var theinfo;

function printstuff(){
	fs.readFile(__dirname + '/test.xml', function(err, data) {
		if (err) throw err;
		console.log("data: \n" + data);
	    parser.parseString(data, function (err, result) {
			if (err) throw err;
			console.log("First Name:\n" + result.info.fname[0]);
	        theinfo += result;
			console.log("Last Name:\n" + result.info.lname[0]);
			     theinfo += result;
		 	console.log("Social Security:\n" + result.info.ssn[0]);
			     theinfo += result;
			console.log("Location:\n" + result.info.location[0]);
						theinfo += result;
			console.log("Age:\n" + result.info.age[0]);
						theinfo += result;

		});
	});
}

var BookID = 1;
connection.query("UPDATE books SET title='Where is Momo',category='Kids' WHERE id='5';",
[title, category, id],
function(err,result){
	if (err) throw err;));
});

UPDATE books SET title='Where is Momo',category='Kids' WHERE id='5';
